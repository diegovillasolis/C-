﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseClassLibraryExamples
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}

//var abstractClass = new AbstractClass();
//var father = new Father();
//Console.WriteLine(((IMyInterface)father).GetName());
//Console.WriteLine(((IMyInterface2)father).GetName());
//MyEnum myEnum = MyEnum.Pair1;

